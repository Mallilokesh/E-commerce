from rest_framework import generics, permissions
from rest_framework.response import Response
from .models import Product, Order, OrderItem
from .serializers import ProductSerializer, OrderSerializer, UserSerializer
from django.contrib.auth.models import User
from knox.models import AuthToken
from rest_framework.views import APIView
from rest_framework.authtoken.serializers import AuthTokenSerializer

class ProductList(generics.ListAPIView):
    queryset = Product.objects.all()
    serializer_class = ProductSerializer

class ProductDetail(generics.RetrieveAPIView):
    queryset = Product.objects.all()
    serializer_class = ProductSerializer

class RegisterAPI(APIView):
    def post(self, request, *args, **kwargs):
        username = request.data.get('username')
        password = request.data.get('password')
        if not username or not password:
            return Response({'error': 'Username and password required'}, status=400)
        if User.objects.filter(username=username).exists():
            return Response({'error': 'Username already taken'}, status=400)
        user = User.objects.create_user(username=username, password=password)
        _, token = AuthToken.objects.create(user)
        return Response({'user': UserSerializer(user).data, 'token': token})

class LoginAPI(APIView):
    def post(self, request, *args, **kwargs):
        serializer = AuthTokenSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data['user']
        _, token = AuthToken.objects.create(user)
        return Response({'user': UserSerializer(user).data, 'token': token})

class OrderCreateAPI(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, *args, **kwargs):
        user = request.user
        items = request.data.get('items', [])
        if not items:
            return Response({'error': 'No items provided'}, status=400)

        order = Order.objects.create(user=user, completed=True)
        for item in items:
            product_id = item.get('product_id')
            quantity = item.get('quantity', 1)
            try:
                product = Product.objects.get(id=product_id)
            except Product.DoesNotExist:
                return Response({'error': f'Product {product_id} not found'}, status=404)
            OrderItem.objects.create(order=order, product=product, quantity=quantity)
        serializer = OrderSerializer(order)
        return Response(serializer.data)
